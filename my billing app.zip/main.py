# import debug_logging_patch
# /////////////////////////////////////////////////////////////////
'''
kivy already define pre-formatting logger
for changing logger formatting we add this code in starting.
'''
import logging
# import sys

# # logging.basicConfig(format='%(asctime)s - %(message)s', level=logging.INFO)
# # "%(asctime)s :: %(levelname)s :: %(filename)s :: %(" \
# #                   "funcName)s() :: Line NO %(lineno)d :: %(" \
# #                   "message)s :: Thread NAME %(threadName)s"

# formatter = logging.Formatter("[%(asctime)s.%(msecs)03d][%(levelname)s][%(filename)s][%(funcName)s][Line NO %("
#                               "lineno)d][%(message)s]", "%H:%M:%S")
# console = logging.StreamHandler()
# console.setFormatter(formatter)
# sys._kivy_logging_handler = console

# ///////////////////////////////////////////////////////////////////

from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivymd.uix.gridlayout import MDGridLayout
from kivy.uix.screenmanager import Screen, ScreenManager, FadeTransition
from kivymd.app import MDApp
from kivy.uix.popup import Popup 
import sqlite3
from kivy.clock import Clock
from kivymd.uix.textfield import MDTextField
from kivymd.uix.label import MDLabel
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDFloatingActionButtonSpeedDial, MDFlatButton
from kivymd.uix.dialog import MDDialog
from kivy.uix.dropdown import DropDown
from kivy.uix.button import Button
from kivy.metrics import dp
from kivy.properties import StringProperty
from kivymd.uix.datatables import MDDataTable
from kivymd.uix.menu import MDDropdownMenu
from kivymd.uix.picker import MDDatePicker

from kivymd.utils import asynckivy

import json 
import datetime
import glob
import shutil
import os
from kivymd.theming import ThemeManager

from manage_databse_fun import user_delete, user_connect, user_view, user_insert, user_update, account_connect, account_insert, accounts_view, account_delete,sales_purchase_connect, sales_purchase_insert, sales_purchases_view, consolated_purchases_view
from Screens_Manager import ScreensManager
from Sign_Screen import SignScreen
from Main_Screen import MainScreen


user_name_label = ''

# complete
class ProfileEditDialog(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        logging.info('initialize Profile pic dialog.')

    def selected(self, filename):
        global user_name_label
        # print("profile pic selected")
        logging.info('Profile pic selected.')
        flag = False
        try:
            # print("SELECTED FILE NAME : ",filename[0])
            
            with open("config.json", "r") as f:
                config_str = f.read()

            config_str_dict = json.loads(config_str) 
            con_user_name = config_str_dict['user_name']
            con_password = config_str_dict['password']

            file_path = filename[0]
            file_path = file_path.split("\\")
            file_path = file_path[-1]
            # print("file_path ::: ",file_path)
            current_directory = os.getcwd()

            final_directory = os.path.join(current_directory, "Profile_Pic")

            if not os.path.exists(final_directory):

                os.makedirs(final_directory)

            # dst_dir = final_directory
            for file in glob.iglob(filename[0]):
                # print("File path for loop : ",file,filename[0])
                selected_path = file.split("\\",-1)
                selected_path = selected_path[0]

                con_file_path = final_directory + os.sep +file_path

                if os.path.isfile(filename[0]):
                    file_extension = os.path.splitext(con_file_path)[1]
                    
                    if file_extension.lower() in {'.jpg', '.jpeg', '.png'}:

                        try:
                            con_file_path = final_directory + os.sep +file_path
                            shutil.copy(file, final_directory)
                            
                            logging.info('Copy Profile pic into app folder.') 
                            flag = False
                        except:
                            logging.info('Error throw in Profile pic copy process.')
                            print("pic copy error")
                    else:
                        flag = True
                        logging.info("Selected File isn't image formate.")
                        print('error')

            
            
            profile_dict = {}
            profile_dict['user_name'] = con_user_name
            
            if flag:
                profile_dict['file_name'] = ''
            else:
                profile_dict['file_name'] = con_file_path
                
            profile_str = json.dumps(profile_dict) 
            # print("SELECTED FILE NAME : type and name ",profile_str, type(profile_str))

            with open("profile.json", "w") as f:
                f.write(profile_str)

            logging.info('Profile pic save into session.')
            # self.dismiss()
           
        except:
            logging.info('Error throw in profile dialog.') 
            # print("profile dialog error")
            pass

# complete
class AllAccountView(Screen):
    def __init__(self, **kwargs):
        super(AllAccountView,self).__init__(**kwargs)
        self.account_set_list()

    # /////////////////////////// Account TABLE /////////////////////////////////////////////
    def account_set_list(self):
        async def account_set_list():
            await asynckivy.sleep(0)

            try:
                self.acc_rows = accounts_view()
                self.acc_rows_num = len(self.acc_rows)
                if not self.acc_rows:
                    self.acc_rows_num = 3

            except:
                self.acc_rows=[]
                self.acc_rows_num = 3

            self.acc_data_table = MDDataTable(
                                    pos_hint={'center_x':0.5,'center_y':0.39},
                                    size_hint=(1,1),
                                    rows_num=self.acc_rows_num,
                                    column_data=[
                                     ("no.",dp(20)),
                                    #  ("Signal Name", dp(60), self.sort_on_signal),
                                     ("NAME",dp(40)),
                                     ("GSTIN",dp(30)),
                                     ("PHONE",dp(45)),
                                     ("ADDRESS",dp(65)),
                                     ("ENTRY DATE",dp(55))

                                    ],

                                    row_data = self.acc_rows,
                                    # sorted_on="NAME",
                                    # sorted_order="ASC",
                                    # elevation=2
                                    )

            self.ids.acc_box.add_widget(self.acc_data_table)

        asynckivy.start(account_set_list())

    
    def refresh_callback(self, *args):
        '''A method that updates the state of your application
        while the spinner remains on the screen.'''

        def refresh_callback(interval):
            self.ids.acc_box.clear_widgets()
            if self.x == 0:
                self.x, self.y = 0, 0
            else:
                self.x, self.y = 0, 0
            self.account_set_list()
            self.ids.refresh_layout.refresh_done()
            self.tick = 0 

        Clock.schedule_once(refresh_callback, 1)
    
    def back_to_secound_screen(self):  
        self.manager.current = 'second_screen'
        self.manager.transition.direction = 'right'

# complete
class PurchaseEntryDialogContant(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs) 
        Clock.schedule_interval(self.control_cgst_sgst_igst, 0.5)
        self.acc_droplist_name = ''
        self.payment_mode_droplist_name = ''
        self.payment_status_droplist_name = ''
        self.pur_entry_date = ''

        # Account name menu item list set in dropdown
        account_menu_items = []
        try:
            self.all_account = accounts_view()
            for i in self.all_account:
                account_menu_items.append(i[1])

            account_menu_items.sort()
            account_menu_items = [{"text": f"{i}"} for i in account_menu_items]
        except:
            account_menu_items=[]

        self.account_menu = MDDropdownMenu(
            caller=self.ids.account_name,
            items=account_menu_items,
            position="center",
            callback=self.set_item_account,
            width_mult=4,
        )

        # payment mode menu item list set in dropdown
        payment_mode_menu_items = ['Cash','Cheque','Mixed','Online']
        payment_mode_menu_items = [{"text": f"{i}"} for i in payment_mode_menu_items]
        self.payment_mode_menu = MDDropdownMenu(
            caller=self.ids.pur_payment_mode_list,
            items=payment_mode_menu_items,
            position="center",
            callback=self.set_item_payment_mode,
            width_mult=4,
        )

        # payment status menu item list set in dropdown
        payment_status_menu_items = ['Cancel','Not Paid','Paid','Partial Paid']
        payment_status_menu_items = [{"text": f"{i}"} for i in payment_status_menu_items]
        self.payment_status_menu = MDDropdownMenu(
            caller=self.ids.pur_payment_status_list,
            items=payment_status_menu_items,
            position="center",
            callback=self.set_item_payment_status,
            width_mult=4,
        )
        
        logging.info('Purchase Entry Dialog initilize.')

    def set_item_account(self, instance):
        # print("set_item_account : ",instance.text)
        self.account_menu.dismiss()
        self.ids.account_name.set_item(instance.text)
        # print("self.all_account :::::: ",self.all_account)
        for i in self.all_account:
            if i[1] == instance.text:
                self.acc_droplist_name = instance.text
                print(i)
                self.ids.pur_address_field.text = i[4]
                self.ids.pur_phone_field.text = i[3]
                self.ids.pur_gstin_field.text = i[2]
                
                
                


    def set_item_payment_mode(self, instance):
        # print("set_item_payment_mode : ",instance.text)
        self.payment_mode_menu.dismiss()
        self.ids.pur_payment_mode_list.set_item(instance.text)
        self.payment_mode_droplist_name = instance.text
        

    def set_item_payment_status(self, instance):
        # print("set_item_payment_status :",instance.text)
        self.payment_status_menu.dismiss()
        self.ids.pur_payment_status_list.set_item(instance.text)
        self.payment_status_droplist_name = instance.text

    def control_cgst_sgst_igst(self,interval):
        # print("control_cgst_sgst_igst")
        pur_cgst_field = self.ids.pur_cgst_field.text
        pur_sgst_field = self.ids.pur_sgst_field.text
        pur_igst_field = self.ids.pur_igst_field.text
        if len(pur_igst_field) > 0:
            self.ids.pur_cgst_field.disabled = True
            self.ids.pur_sgst_field.disabled = True
        else:
            self.ids.pur_cgst_field.disabled = False
            self.ids.pur_sgst_field.disabled = False
        
        if (len(pur_sgst_field) > 0) or (len(pur_cgst_field) > 0):
            # print("VED")
            self.ids.pur_igst_field.disabled = True
        else:
            self.ids.pur_igst_field.disabled = False

    def show_date_picker(self):
        print("date")  
        date_dialog = MDDatePicker(
            callback=self.get_date,

        )
        date_dialog.open()      

    def get_date(self,the_date):
        self.pur_entry_date = the_date
        print(the_date)



class AccountAddDialog(BoxLayout):
   
    def __init__(self, **kwargs):
        self.window= Window
        super().__init__(**kwargs)
        logging.info('Account add dialog initialize.')


#complete
class AccountDeleteContant(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs) 
        # Clock.schedule_interval(self.control_cgst_sgst_igst, 0.5)
        self.acc_droplist_name = ''
        

        # Account name menu item list set in dropdown
        
        try:
            account_menu_items = []
            self.all_account = accounts_view()
            for i in self.all_account:
                account_menu_items.append(i[1])

            account_menu_items.sort()
            account_menu_items = [{"text": f"{i}"} for i in account_menu_items]
        except:
            account_menu_items=[]

        self.account_menu = MDDropdownMenu(
            caller=self.ids.account_name_for_delete_dropdown,
            items=account_menu_items,
            position="center",
            callback=self.set_item_account,
            width_mult=4,
        )
        
        logging.info('Account delete contant initialize.')

        
    def set_item_account(self, instance):
        self.account_menu.dismiss()
        self.ids.account_name_for_delete_dropdown.set_item(instance.text)

        for i in self.all_account:
            if i[1] == instance.text:
                self.acc_droplist_name = instance.text
                print(i)
                self.ids.acc_del_name_field.text = i[1]
                self.ids.acc_del__phone_field.text = i[3]
                self.ids.acc_del_gstin_field.text = i[2]
                self.ids.acc_del_address_field.text = i[4]
                
                
                


    # def set_item_payment_mode(self, instance):
    #     # print("set_item_payment_mode : ",instance.text)
    #     self.payment_mode_menu.dismiss()
    #     self.ids.pur_payment_mode_list.set_item(instance.text)
    #     self.payment_mode_droplist_name = instance.text
        

    # def __init__(self, **kwargs):
    #     self.window= Window
    #     super().__init__(**kwargs)
    #     self.title="ACCOUNT ENTRY"
    #     #self.size_hint=(None, None)
    #     self.size=(800, 1200)

    # def closeDialog(self):
    #     print("cancel")
    #     self.dismiss()


    # def account_dialog_save_btn(self):
    #     print("edit")
    #     account_name = self.ids.purchser_name_field.text
    #     account_gst_in = self.ids.gstin_field.text
    #     account_phone = self.ids.phone_field.text
    #     account_address = self.ids.address_field.text
    #     date_time = datetime.datetime.now()

    #     print(account_name,account_gst_in,account_phone,account_address)
    #     account_connect()
    #     account_insert(account_name, account_gst_in, account_phone, account_address, date_time)
    #     self.dismiss()
    #     print("##########################DATA BASE ACCOUNCTS ##############################")
    #     print(accounts_view())

# complete
class AccountEditDialog(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        logging.info('Initialize account edit Dialog.')

# complete
class PurchasedScreen(Screen):
    def __init__(self, **kwargs):
        super(PurchasedScreen,self).__init__(**kwargs)
        logging.info('Purchase Screen initialize.')
        logging.info('Purchase datatable start initializing.')
        self.set_list()
        logging.info('Purchase datatable finish initializing.')

    # /////////////////////////// PURCHASE TABLE /////////////////////////////////////////////
    def set_list(self):
        async def set_list():
            await asynckivy.sleep(0)

            try:
                self.pur_rows = sales_purchases_view('purchase_entry')
                self.pur_rows_num = len(self.pur_rows)
                if not self.pur_rows:
                    self.pur_rows_num = 3

                self.pur_rows_list = []
                for i in self.pur_rows:
                    y = list(i)
                    y.pop(-1)
                    y.pop(-1)
                    i = tuple(y)
                    self.pur_rows_list.append(i)
            except:
                self.pur_rows_list = []
                self.pur_rows_num = 3

            self.pur_data_table = MDDataTable(
                                    pos_hint={'center_x':0.5,'center_y':0.39},
                                    size_hint=(1,1),
                                    # rows_num=self.pur_rows_num,
                                    rows_num=25,
                                    use_pagination=True,
                                    column_data=[
                                        ("no.",dp(20)),
                                        ("Name",dp(30)),
                                        ("GSTIN",dp(25)),
                                        ("Bill Number",dp(25)),
                                        ("Bill Amount",dp(30)),
                                        ("CGST",dp(25)),
                                        ("SGST",dp(25)),
                                        ("IGST",dp(25)),
                                        ("Payment Mode",dp(25)),
                                        ("Payment Status",dp(30)),
                                        ("Entry Date",dp(55)),
                                        ("Description",dp(80)),
                                        ("Phone Number",dp(35)),
                                        ("ADDRESS",dp(60))

                                    ],
                                    
                                    # row_data = self.pur_rows,
                                    row_data = self.pur_rows_list,
                                    # sorted_on="NAME",
                                    # sorted_order="ASC",
                                    # elevation=2
                                    )

            # self.pur_data_table.bind(on_check_press=self.check_press)
            # self.pur_data_table.bind(on_row_press=self.row_press)
            self.ids.box.add_widget(self.pur_data_table)

        asynckivy.start(set_list())

    def refresh_callback(self, *args):
        '''A method that updates the state of your application
        while the spinner remains on the screen.'''

        def refresh_callback(interval):
            self.ids.box.clear_widgets()
            if self.x == 0:
                self.x, self.y = 0, 0
            else:
                self.x, self.y = 0, 0
            self.set_list()
            self.ids.refresh_layout.refresh_done()
            self.tick = 0 

        Clock.schedule_once(refresh_callback, 1)
   
    # def check_press(self,instance_table, current_row):
    #     print(instance_table,current_row)

    # def row_press(self, instance_table, instance_row):
    #     print(instance_table, instance_row)
    

    def back_to_secound_screen(self):
        self.manager.current = 'second_screen'
        self.manager.transition.direction = 'right'
        logging.info('Back button click to jump second screen purchased.')
        # print("back button click to jump second screen purchased.")

    def purchase_entry_fun(self):
        # print("purchase_entry_fun") 
        self.dialog = None

        if not self.dialog: 
            self.content_cls = PurchaseEntryDialogContant()
            self.dialog = MDDialog(
                title="Purchase Entry:",
                type="custom",
                size_hint= [0.9, None],
                content_cls=self.content_cls,
                buttons=[
                    MDFlatButton(
                        text="CANCEL", text_color= (1,0,1,1), on_release= self.pur_entry_closeDialog
                    ),
                    MDFlatButton(
                        text="OK", text_color=(1,0,1,1), on_release=self.pur_entry_grabText
                    ),
                ],
            )
        self.dialog.set_normal_height()
        self.dialog.open()
        
        logging.info('Purchase Entry Dialog open.')

    

    def pur_entry_closeDialog(self, inst):
        self.dialog.dismiss()

    def pur_entry_grabText(self, inst):
        
        for obj in self.dialog.content_cls.children:
            print("obj : ",obj)
            content_cls = self.content_cls

            with open("config.json", "r") as f:
                config_str = f.read()

            config_str_dict = json.loads(config_str) 
            user_name = config_str_dict['user_name']

            pur_account_name = content_cls.acc_droplist_name 
            pur_payment_mode_list = content_cls.payment_mode_droplist_name 
            pur_payment_status_list = content_cls.payment_status_droplist_name 
            pur_entry_date = content_cls.pur_entry_date
            login_user_name = user_name

            # pur_account_name = pur_account_name
            pur_address_field = content_cls.ids.pur_address_field.text
            pur_phone_field = content_cls.ids.pur_phone_field.text

            # print(pur_account_name,pur_address_field,pur_phone_field)

            pur_gstin_field = content_cls.ids.pur_gstin_field.text
            pur_bill_number_field = content_cls.ids.pur_bill_number_field.text
            pur_bill_amount_field = content_cls.ids.pur_bill_amount_field.text

            # print(pur_gstin_field,pur_bill_number_field,pur_bill_amount_field)

            pur_cgst_field = content_cls.ids.pur_cgst_field.text
            pur_sgst_field = content_cls.ids.pur_sgst_field.text
            pur_igst_field = content_cls.ids.pur_igst_field.text

            # print(pur_cgst_field,pur_sgst_field,pur_igst_field)

            pur_description_field = content_cls.ids.pur_description_field.text
            # pur_payment_mode_list = pur_payment_mode_list
            # pur_payment_status_list = pur_payment_status_list

            # print(pur_description_field,pur_payment_mode_list,pur_payment_status_list,pur_entry_date)
            
            # purchase_connect()
            logging.info('Purchase Entry Dialog field value grab.')
            sales_purchase_insert(pur_account_name, pur_gstin_field, pur_bill_number_field, pur_bill_amount_field, pur_cgst_field, pur_sgst_field, pur_igst_field, pur_payment_mode_list, pur_payment_status_list, pur_entry_date,pur_description_field, pur_phone_field, pur_address_field, login_user_name,'purchase_entry')
            logging.info('Purchase Entry insert to database table.')
            
        self.dialog.dismiss()
        self.refresh_callback()
        # print("purchase entry complete")
        


class ConsolatedScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.set_list()
        logging.info('Purchase datatable finish initializing.')

    # /////////////////////////// PURCHASE TABLE /////////////////////////////////////////////
    def set_list(self):
        async def set_list():
            await asynckivy.sleep(0)

            try:
                self.pur_rows = consolated_purchases_view()
                self.pur_rows_num = len(self.pur_rows)
                if not self.pur_rows:
                    self.pur_rows_num = 3

                self.pur_rows_list = []
                for i in self.pur_rows:
                    y = list(i)
                    y.pop(-1)
                    y.pop(-1)
                    i = tuple(y)
                    self.pur_rows_list.append(i)
            except:
                self.pur_rows_list = []
                self.pur_rows_num = 3

            self.pur_data_table = MDDataTable(
                                    pos_hint={'center_x':0.5,'center_y':0.39},
                                    size_hint=(1,1),
                                    # rows_num=self.pur_rows_num,
                                    rows_num=25,
                                    use_pagination=True,
                                    column_data=[
                                        ("no.",dp(20)),
                                        ("Name",dp(30)),
                                        ("GSTIN",dp(25)),
                                        ("Bill Number",dp(25)),
                                        ("Bill Amount",dp(30)),
                                        ("CGST",dp(25)),
                                        ("SGST",dp(25)),
                                        ("IGST",dp(25)),
                                        ("Payment Mode",dp(25)),
                                        ("Payment Status",dp(30)),
                                        ("Entry Date",dp(55)),
                                        ("Description",dp(80)),
                                        ("Phone Number",dp(35)),
                                        ("ADDRESS",dp(60))

                                    ],
                                    
                                    # row_data = self.pur_rows,
                                    row_data = self.pur_rows_list,
                                    # sorted_on="NAME",
                                    # sorted_order="ASC",
                                    # elevation=2
                                    )

            # self.pur_data_table.bind(on_check_press=self.check_press)
            # self.pur_data_table.bind(on_row_press=self.row_press)
            self.ids.box.add_widget(self.pur_data_table)

        asynckivy.start(set_list())

    def refresh_callback(self, *args):
        '''A method that updates the state of your application
        while the spinner remains on the screen.'''

        def refresh_callback(interval):
            self.ids.box.clear_widgets()
            if self.x == 0:
                self.x, self.y = 0, 0
            else:
                self.x, self.y = 0, 0
            self.set_list()
            self.ids.refresh_layout.refresh_done()
            self.tick = 0 
        Clock.schedule_once(refresh_callback, 1)

    def back_to_secound_screen(self):
        self.manager.current = 'second_screen'
        self.manager.transition.direction = 'right'



# complete
class SaleScreen(Screen):
   
    def __init__(self, **kwargs):
        super(SaleScreen,self).__init__(**kwargs)
        logging.info('Sale screen initilize.')
        logging.info('Sales datatable start initializing.')
        self.set_list()
        logging.info('Sales datatable finish initializing.')

        # /////////////////////////// Sale TABLE /////////////////////////////////////////////
    def set_list(self):
        async def set_list():
            await asynckivy.sleep(0)

            try:
                self.sale_rows = sales_purchases_view('sales_entry')
                self.sale_rows_num = len(self.sale_rows)
                if not self.sale_rows:
                    self.sale_rows_num = 3

                self.sale_rows_list = []
                for i in self.sale_rows:
                    y = list(i)
                    y.pop(-1)
                    y.pop(-1)
                    i = tuple(y)
                    self.sale_rows_list.append(i)
            except:
                self.sale_rows_num = 3
                self.sale_rows_list = []

            self.sale_data_table = MDDataTable(
                                    pos_hint={'center_x':0.5,'center_y':0.39},
                                    size_hint=(1,1),
                                    rows_num=25,
                                    use_pagination=True,
                                    column_data=[
                                        ("no.",dp(20)),
                                        #  ("NAME",dp(30), self.sort_on_name),
                                        ("Name",dp(30)),
                                        ("GSTIN",dp(25)),
                                        ("Bill Number",dp(25)),
                                        ("Bill Amount",dp(30)),
                                        ("CGST",dp(25)),
                                        ("SGST",dp(25)),
                                        ("IGST",dp(25)),
                                        ("Payment Mode",dp(25)),
                                        ("Payment Status",dp(30)),
                                        ("Entry Date",dp(55)),
                                        ("Description",dp(80)),
                                        ("Phone Number",dp(35)),
                                        ("ADDRESS",dp(60))
                                    ],
                                    row_data = self.sale_rows_list,
                                    )

            self.ids.box.add_widget(self.sale_data_table)
            # self.sale_data_table.bind(create_pagination_menu=self.create_pagination_menu)
            # /////////////////////////////////////////////////////////////
        asynckivy.start(set_list())

    def create_pagination_menu(self, interval):
        print('datatable menu set')
        
    def refresh_callback(self, *args):
        '''A method that updates the state of your application
        while the spinner remains on the screen.'''

        def refresh_callback(interval):
            self.ids.box.clear_widgets()
            if self.x == 0:
                self.x, self.y = 0, 0
            else:
                self.x, self.y = 0, 0
            self.set_list()
            self.ids.refresh_layout.refresh_done()
            self.tick = 0 

        Clock.schedule_once(refresh_callback, 1)

    def back_to_secound_screen(self):
        self.manager.current = 'second_screen'
        self.manager.transition.direction = 'right'
        print("back to second screen from sale.")
        # self.current = "second_screen"

    def sale_entry_fun(self):
        self.dialog = None

        if not self.dialog: 
            self.content_cls = PurchaseEntryDialogContant()
            self.dialog = MDDialog(
                title="Sale Entry:",
                type="custom",
                size_hint= [0.9, None],
                content_cls=self.content_cls,
                buttons=[
                    MDFlatButton(
                        text="CANCEL", text_color= (1,0,1,1), on_release= self.acc_entry_closeDialog
                    ),
                    MDFlatButton(
                        text="OK", text_color=(1,0,1,1), on_release=self.acc_entry_grabText
                    ),
                ],
            )
        self.dialog.set_normal_height()
        self.dialog.open()

    

    def acc_entry_closeDialog(self, inst):
        self.dialog.dismiss()

    def acc_entry_grabText(self, inst):
        
        for obj in self.dialog.content_cls.children:
            content_cls = self.content_cls

            with open("config.json", "r") as f:
                config_str = f.read()

            config_str_dict = json.loads(config_str) 
            user_name = config_str_dict['user_name']

            sale_account_name = content_cls.acc_droplist_name 
            sale_payment_mode_list = content_cls.payment_mode_droplist_name 
            sale_payment_status_list = content_cls.payment_status_droplist_name 
            sale_entry_date = content_cls.pur_entry_date
            login_user_name = user_name

            sale_address_field = content_cls.ids.pur_address_field.text
            sale_phone_field = content_cls.ids.pur_phone_field.text

            sale_gstin_field = content_cls.ids.pur_gstin_field.text
            sale_bill_number_field = content_cls.ids.pur_bill_number_field.text
            sale_bill_amount_field = content_cls.ids.pur_bill_amount_field.text

            sale_cgst_field = content_cls.ids.pur_cgst_field.text
            sale_sgst_field = content_cls.ids.pur_sgst_field.text
            sale_igst_field = content_cls.ids.pur_igst_field.text

            sale_description_field = content_cls.ids.pur_description_field.text

            logging.info('Sales entry dialog field value grab.')
            sales_purchase_insert(sale_account_name, sale_gstin_field, sale_bill_number_field, sale_bill_amount_field, sale_cgst_field, sale_sgst_field, sale_igst_field, sale_payment_mode_list, sale_payment_status_list, sale_entry_date,sale_description_field, sale_phone_field, sale_address_field, login_user_name,'sales_entry')
            logging.info('Sales entry insert into datatable table.')

        self.dialog.dismiss()
        self.refresh_callback()
        print("purchase entry complete")


class SecondScreen(Screen):
    def __init__(self, **kwargs):
        super(SecondScreen, self).__init__(**kwargs)
        Clock.schedule_interval(self.update_username_label, 0.5)
        Clock.schedule_once(self.floating_action_button_fun)

        self.data = {
            'account-plus': 'ADD ACCOUNT',
            'account-remove': 'DELETE ACCOUNT',
            'account-details': 'VIEW ALL',
        }
        
        logging.info('Second Screen initialize.')

    # complete
    def floating_action_button_fun(self, dt):
        speed_dial = MDFloatingActionButtonSpeedDial(callback=self.callback)
        # speed_dial.hint_animation: True
        speed_dial.data = self.data
        speed_dial.opening_transition = 'out_cubic'
        speed_dial.rotation_root_button = True
        self.add_widget(speed_dial)

    # complete
    def update_username_label(self, dt):

        try:
            with open("config.json", "r") as f:
                config_str = f.read()

            # print("login_frm_database 21")
            config_str_dict = json.loads(config_str) 
            self.con_user_name = config_str_dict['user_name']
            con_password = config_str_dict['password']
        except:
            config_str_dict = {}
            self.con_user_name = 'con_user_name'
            con_password = ''
            profile_file_path = 'account-circle'
        try:
                with open("profile.json", "r") as f:
                    profile_str = f.read()

                profile_str_dict = json.loads(profile_str) 
                profile_file_path = profile_str_dict['file_name']

                profile_file_path = profile_file_path.replace("\\","//")
                if len(profile_file_path) == 0:
                    profile_file_path = 'account-circle'
            #     print('Error in reading profile pic path')

        except:
            config_str_dict = {}
            self.con_user_name = 'con_user_name'
            con_password = ''
            profile_file_path = 'account-circle'
            # print("update_username_label ERROR CONFIG")
        
        if len(self.con_user_name) > 3:
            # print("profile_file_path ",profile_file_path)
            self.ids.user_name_label.text = self.con_user_name
            self.ids.profile_image_btn.icon = profile_file_path
            # print("update_username_label CONFIG USERNAME")
        else:
            try:
                # print("profile_file_path ",profile_file_path)
                self.ids.user_name_label.text = user_name_label
                self.ids.profile_image_btn.icon = profile_file_path
            except:
                self.ids.user_name_label.text = "USER"
        # self.ids.user_name_label.text = "USER"
        self.ids.user_name_label.theme_text_color = 'Secondary'

    # complete
    def callback(self, instance):
        if instance.icon == 'account-plus':
            self.account_plus_btn_fun()
        if instance.icon == 'account-remove':
            self.account_delete_btn_fun()
        if instance.icon == 'account-details':
            self.account_view_all_btn_fun()

    # complete
    def edit_user_account(self):
        logging.info('Update user account fun call.')
        self.dialog = None
        if not self.dialog: 
            self.account_content_cls = AccountEditDialog()
            self.dialog = MDDialog(
                title="User Account Edit",
                type="custom",
                size_hint= [0.7, 0.6],
                # # type="custom",
                # height=dp(800),
                content_cls=self.account_content_cls,
                buttons=[
                    MDFlatButton(
                        text="Cancel", text_color= (1,0,1,1), on_release= self.acc_edit_closeDialog
                    ),
                    MDFlatButton(
                        text="Edit", text_color=(1,0,1,1), on_release=self.acc_edit_grabText
                    ),
                ],
            )
        self.dialog.set_normal_height()
        self.dialog.open()
        logging.info('User account update dialog open.')

    
    # complete
    def acc_edit_closeDialog(self, inst):
        self.dialog.dismiss()

    # complete
    def acc_edit_grabText(self, inst):
        logging.info('User Account edit field Values get.')
        for obj in self.dialog.content_cls.children:
            print("obj : ",obj)
            content_cls = self.account_content_cls

            acc_username_field = content_cls.ids.acc_username_field.text
            acc_password_field = content_cls.ids.acc_password_field.text
            acc_repassword_field = content_cls.ids.acc_repassword_field.text

            if acc_password_field == acc_repassword_field:
                user_update(acc_username_field,acc_password_field,self.con_user_name)

                acc_edit_dict = {}
                acc_edit_dict['user_name'] = acc_username_field
                acc_edit_dict['password'] = acc_password_field
                acc_edit_config_str = json.dumps(acc_edit_dict) 

                with open("config.json", "w") as f:
                    f.write(acc_edit_config_str)

                logging.info('Update User Account and also set into session.')
                # print("ACC: ",acc_username_field,acc_password_field,acc_repassword_field)
                self.dialog.dismiss()
            else:
                logging.info('ACCOUNT EDIT PASSWORD NOT MATCHED.')
                print('ACCOUNT EDIT PASSWORD NOT MATCHED.')

    # complete
    def profile_change_fun(self):
        logging.info('Profile update function call.')
        self.dialog = None
        if not self.dialog: 
            self.profile_content_cls = ProfileEditDialog()
            self.dialog = MDDialog(
                title="Profile Pic Change",
                type="custom",
                size_hint= [0.7, .6],
                content_cls=self.profile_content_cls,
                # buttons=[
                #     MDFlatButton(
                #         text="Cancel", text_color= (1,0,1,1), on_release= self.acc_edit_closeDialog
                #     )
                    
                # ],
            )
        self.dialog.set_normal_height()
        self.dialog.open()
        logging.info('file manager open.')
    
    # complete
    def account_plus_btn_fun(self):      
        logging.info('Account add dialog fuction call.')
        self.dialog = None

        if not self.dialog: 
            self.acc_plus_content_cls = AccountAddDialog()
            self.dialog = MDDialog(
                title="Account",
                type="custom",
                # size_hint= [0.8, .5],
                # # type="custom",
                # height=dp(800),
                content_cls=self.acc_plus_content_cls,
                buttons=[
                    MDFlatButton(
                        text="Cancel", text_color= (1,0,1,1), on_release= self.acc_plus_closeDialog
                    ),
                    MDFlatButton(
                        text="Save", text_color=(1,0,1,1), on_release=self.acc_plus_grabText
                    ),
                ],
            )
        self.dialog.set_normal_height()
        self.dialog.open()
        logging.info('Account add dialog open.')
        # print('account_plus_btn_fun')
    
    # complete
    def acc_plus_closeDialog(self,inst):
        self.dialog.dismiss()

    # complete
    def acc_plus_grabText(self,inst):
        for obj in self.dialog.content_cls.children:
            print("obj : ",obj)
            content_cls = self.acc_plus_content_cls

            acc_plus_name_field = content_cls.ids.acc_plus_name_field.text
            acc_plus_phone_field = content_cls.ids.acc_plus_phone_field.text
            acc_plus_gstin_field = content_cls.ids.acc_plus_gstin_field.text
            acc_plus_address_field = content_cls.ids.acc_plus_address_field.text
            acc_plus_date_time = datetime.datetime.now()
            
            logging.info('Account add field value grab.')
            account_insert(acc_plus_name_field, acc_plus_gstin_field, acc_plus_phone_field, acc_plus_address_field, acc_plus_date_time)
            self.dialog.dismiss()
            logging.info('Account entry insert into database.')
                
    #complete
    def account_delete_btn_fun(self):

        self.dialog = None

        if not self.dialog: 
            self.acc_del_content_cls = AccountDeleteContant()
            self.dialog = MDDialog(
                title="Delete Account:",
                type="custom",
                size_hint= [0.9, None],
                content_cls=self.acc_del_content_cls,
                buttons=[
                    MDFlatButton(
                        text="CANCEL", text_color= (1,0,1,1), on_release= self.acc_del_closeDialog
                    ),
                    MDFlatButton(
                        text="OK", text_color=(1,0,1,1), on_release=self.acc_del_grabText
                    ),
                ],
            )
        self.dialog.set_normal_height()
        self.dialog.open()

    
    #complete
    def acc_del_closeDialog(self, inst):
        self.dialog.dismiss()

    #complete
    def acc_del_grabText(self, inst):
        
        for obj in self.dialog.content_cls.children:
            # print("obj : ",obj)
            content_cls = self.acc_del_content_cls
            account_name_for_del = content_cls.acc_droplist_name
            # print(account_name_for_del)
            account_delete(account_name_for_del)
            self.dialog.dismiss()
        logging.info('Account delete from database.')

    # complete
    def account_view_all_btn_fun(self):
        # print("account_view_all_btn_fun 1")
        self.manager.current = "all_account_view"
        self.manager.transition.direction = 'left' 

    # complete
    def logout_fun(self):
        # user_delete()
        config_str = ''
        with open("config.json", "w") as f:
            f.write(config_str)
        
        logging.info('Logout user successfully.')
        # print("logout button clicked.")
        

    def dark_mode_fun(self,checkbox, value):
        print("theme change")
        # if value:
        #     ThemeManager.theme_cls.theme_style = 'Dark'
        # else:
        #     ThemeManager.theme_cls.theme_style = 'Light'

class mainApp(MDApp):
    theme_clss = None
    def __init__(self, **kwargs):
        self.title = "Billing App"
        self.theme_cls.primary_palette = 'Indigo'
        self.theme_cls.theme_style = 'Dark'

        super().__init__(**kwargs)
        
    logging.info('Start Application!')

    def build(self):
        return ScreensManager()


if __name__ == "__main__":
    mainApp().run()
