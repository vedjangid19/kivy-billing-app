from kivy.uix.screenmanager import Screen, ScreenManager, FadeTransition
from manage_databse_fun import user_connect, user_insert, user_view
import json
import logging

class MainScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        logging.info('Login Screen initialize.')
        
    def login_user(self):
        global user_name_label

        # user_connect()
        username = self.ids.user_field.text
        password = self.ids.password_field.text
        # print("type_one function call", username, password)
        logging.info('Username and password get from field.')
        all_userr = user_view()
        print('All User',all_userr)
        for i in all_userr:
            # print(i[1],i[3])
            if username == i[1] and password == i[3]:
                # if password == i[3]:
                    logging.info('You are login.')
                    # print("user_name_label : ",user_name_label)
                    user_name_label = username

                    dict = {}
                    dict['user_name'] = username
                    dict['password'] = password
                    config_str = json.dumps(dict) 

                    with open("config.json", "w") as f:
                        f.write(config_str)

                    logging.info('Username and password save into session.')
                    # print("user_name_label : ",user_name_label)
                    self.manager.current = 'second_screen'
                    break