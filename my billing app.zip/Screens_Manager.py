from kivy.uix.screenmanager import Screen, ScreenManager, FadeTransition
import json
import logging

class ScreensManager(ScreenManager):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        logging.info('Screens Manager initialize.')
        self.login_frm_database()

    def login_frm_database(self):

        try:
            with open("config.json", "r") as f:
                config_str = f.read()
            # print("before load data",config_str)
            config_str_dict = json.loads(config_str) 
            # print("after load data")
            user_name = config_str_dict['user_name']
            password = config_str_dict['password']
            if len(user_name) > 3:
                if len(password) > 3:
                    self.current = "second_screen"
                    logging.info('User already save in session, APP directly login from session.')

        except:
            logging.info('User not Found in session please login/signup.')
            print('User not Found in session please login/signup.')
            pass
    