from kivy.uix.screenmanager import Screen, ScreenManager, FadeTransition
from manage_databse_fun import user_connect, user_insert
import logging

class SignScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        logging.info('SignUp Screen initialize.')

    def signup_user(self):
        username = self.ids.user_field.text
        password = self.ids.password_field.text
        re_password = self.ids.repassword_field.text
        phone_num = self.ids.phone_field.text
        
        logging.info('User detail Collected from field.')
        
        if password == re_password:
            # print("signup form detail : ",username,password,re_password,phone_num)
            user_connect()
            user_insert(username, phone_num, password)
            logging.info('User details inserted into database.')
            self.manager.current = 'main_screen'