import sqlite3

def user_connect():
    conn = sqlite3.connect("management.db")
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS user (id INTEGER PRIMARY KEY, user_name text, user_phone text, user_password text)")
    conn.commit()
    conn.close()


def user_insert(name, phone, pwd):
    user_connect()
    conn = sqlite3.connect("management.db")
    cur = conn.cursor()
    cur.execute("INSERT INTO user VALUES (NULL,?,?,?)", (name, phone, pwd))
    conn.commit()
    conn.close()
    print(user_view())


def user_view():
    user_connect()
    conn = sqlite3.connect("management.db")
    cur = conn.cursor()
    cur.execute("SELECT * FROM user")
    rows = cur.fetchall()
    conn.close()
    return rows


def user_delete():
    user_connect()
    conn = sqlite3.connect("management.db")
    cur = conn.cursor()
    cur.execute("DELETE FROM user WHERE id=?",(1,))
    conn.commit()
    conn.close()


def user_update(uname,password,old_username):
    print(uname,password,old_username)
    user_connect()
    conn=sqlite3.connect("management.db")
    cur=conn.cursor()
    cur.execute("UPDATE user SET user_name=?, user_password=? WHERE user_name=?",(uname,password,old_username))
    # 'UPDATE version SET ver=?, author=?, year=?, isbn=? WHERE id=?",(title,author,year,isbn,id)'
    conn.commit()
    conn.close()

# ########################### ACCOUNT TABLE #######################################
def account_connect():
    conn = sqlite3.connect("management.db")
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS accounts (id INTEGER PRIMARY KEY, account_name text, gst_in text, phone text, account_address text, date_time text )")
    conn.commit()
    conn.close()

def account_insert(account_name, gst_in, phone, account_address, date_time):
    account_connect()
    conn = sqlite3.connect("management.db")
    cur = conn.cursor()
    cur.execute("INSERT INTO accounts VALUES (NULL,?,?,?,?,?)", (account_name, gst_in, phone, account_address, date_time))
    conn.commit()
    conn.close()
    print(user_view())


def accounts_view():
    account_connect()
    conn = sqlite3.connect("management.db")
    cur = conn.cursor()
    cur.execute("SELECT * FROM accounts")
    rows = cur.fetchall()
    conn.close()
    return rows

def account_delete(account_name):
    account_connect()
    conn = sqlite3.connect("management.db")
    cur = conn.cursor()
    cur.execute("DELETE FROM accounts WHERE account_name=?",(account_name,))
    conn.commit()
    conn.close()


# ############################### PURCHASE TABLE#############################################

def sales_purchase_connect():
    conn = sqlite3.connect("management.db")
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS sales_purchases_table (id INTEGER PRIMARY KEY,purchase_name text,gst_in text,purchase_bill_number text,purchase_bill_amount text, purchase_cgst text, purchase_sgst text, purchase_igst text,purchase_payment_mode text, purchase_payment_status text, purchase_date_time text,purchase_description text,purchase_phone text, purchase_address text,acc_user_name text,entry_type text )")
    conn.commit()
    conn.close()

def sales_purchase_insert(purchase_name, gst_in, purchase_bill_number, purchase_bill_amount, purchase_cgst, purchase_sgst, purchase_igst, purchase_payment_mode, purchase_payment_status, purchase_date_time, purchase_description, purchase_phone, purchase_address, acc_user_name,entry_type):
    sales_purchase_connect()
    conn = sqlite3.connect("management.db")
    cur = conn.cursor()
    cur.execute("INSERT INTO sales_purchases_table VALUES (NULL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (purchase_name, gst_in, purchase_bill_number, purchase_bill_amount, purchase_cgst, purchase_sgst, purchase_igst, purchase_payment_mode, purchase_payment_status, purchase_date_time, purchase_description, purchase_phone, purchase_address, acc_user_name,entry_type))
    conn.commit()
    conn.close()
    # print(purchases_view())

def sales_purchases_view(entry_type):
    sales_purchase_connect()
    conn = sqlite3.connect("management.db")
    cur = conn.cursor()
    cur.execute("SELECT * FROM sales_purchases_table WHERE entry_type=?",(entry_type,))
    rows = cur.fetchall()
    # print(type(rows))
    # print(type(cur.fetchall()))
    conn.close()
    return rows

def consolated_purchases_view():
    sales_purchase_connect()
    conn = sqlite3.connect("management.db")
    cur = conn.cursor()
    cur.execute("SELECT * FROM sales_purchases_table")
    rows = cur.fetchall()
    # print(type(rows))
    # print(type(cur.fetchall()))
    conn.close()
    return rows

def sales_purchase_delete(id):
    sales_purchase_connect()
    conn = sqlite3.connect("management.db")
    cur = conn.cursor()
    cur.execute("DELETE FROM sales_purchases_table WHERE id=?",(id,))
    conn.commit()
    conn.close()


# purchase_delete(22)
# ############################### SALE TABLE#############################################

# def sales_connect():
#     conn = sqlite3.connect("management.db")
#     cur = conn.cursor()
#     cur.execute("CREATE TABLE IF NOT EXISTS sales (id INTEGER PRIMARY KEY,sale_name text,gst_in text,sale_bill_number text,sale_bill_amount text, sale_cgst text, sale_sgst text, sale_igst text,sale_payment_mode text, sale_payment_status text, sale_date_time text,sale_description text,sale_phone text, sale_address text,acc_user_name text )")
#     conn.commit()
#     conn.close()

# def sales_insert(sale_name, gst_in, sale_bill_number, sale_bill_amount, sale_cgst, sale_sgst, sale_igst, sale_payment_mode, sale_payment_status, sale_date_time, sale_description, sale_phone, sale_address, acc_user_name):
    
#     conn = sqlite3.connect("management.db")
#     cur = conn.cursor()
#     cur.execute("INSERT INTO sales VALUES (NULL,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (sale_name, gst_in, sale_bill_number, sale_bill_amount, sale_cgst, sale_sgst, sale_igst, sale_payment_mode, sale_payment_status, sale_date_time, sale_description, sale_phone, sale_address, acc_user_name))
#     conn.commit()
#     conn.close()
#     # print(purchases_view())

# def sales_view():
#     conn = sqlite3.connect("management.db")
#     cur = conn.cursor()
#     cur.execute("SELECT * FROM sales")
#     rows = cur.fetchall()
#     conn.close()
#     return rows



# def sales_delete(purchases_name):
#     conn = sqlite3.connect("management.db")
#     cur = conn.cursor()
#     cur.execute("DELETE FROM sales WHERE account_name=?",(account_name,))
#     conn.commit()
#     conn.close()


# purchase_connect()
# sales_connect()
# # import time

# # t1 = time.time()
# for i in range(0,25):
#     sales_insert(f'{i} pur_account_name', f'{i} pur_gstin_field', f'{i} pur_bill_number_field', f'{i} pur_bill_amount_field', f'{i} pur_cgst_field', f'{i} pur_sgst_field', f'{i} pur_igst_field', f'{i} pur_payment_mode_list', f'{i} pur_payment_status_list', f'{i} pur_entry_date',f'{i} pur_description_field', f'{i} pur_phone_field', f'{i} pur_address_field', f'{i} login_user_name')
#     with open('database_entry_txt.txt','a') as f:
#         f.write('''
#         'pur_account_name', 'pur_gstin_field', 'pur_bill_number_field', 'pur_bill_amount_field', 'pur_cgst_field', 'pur_sgst_field', 'pur_igst_field', 'pur_payment_mode_list', 'pur_payment_status_list', 'pur_entry_date','pur_description_field', 'pur_phone_field', 'pur_address_field', 'login_user_name'
         
#          ''')
#     print(f'entry count {i}')
# t2 = time.time()
# print(f'{t1} - {t2} = ',t2-t1,(t2-t1)/1000)
# print('///////////////////////////////entry done///////////////////////////////////')

# import time
# import logging
# logging.basicConfig(format='%(asctime)s - %(message)s', level=logging.INFO)
# t1 = time.time()
# purchase_connect()
# print(purchases_view())
# logging.info('Start Application!')
# t2 = time.time()
# print(f'{t1} - {t2} = ',t2-t1,(t2-t1)/1000)